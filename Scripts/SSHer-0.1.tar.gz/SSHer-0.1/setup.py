from distutils.core import setup

setup(
    name='SSHer',
    version='0.1',
    author='Guido Accardo',
    author_email='gaccardo@gmail.com',
    scripts=['bin/install.sh'],
    packages=['ssher'],
    url='http://pypi.python.org/pypi/SSHer/',
    license='LICENSE.txt',
    description='SSH connections starter',
    long_description=open('README.txt').read(),
    install_requires=[
        "blessings >= 1.5.1",
    ],)
